README

run the program by doing this

I am using python 2.7

virtualenv venv
source venv/bin/activate
pip install -r requirements.txt


run by executing

python hw2.py -q TITIN_Human.fa -r TITIN_Mouse.fa -m TITIN_Match.txt
python hw2.py -q TITIN_Human.fa -r TITIN_Mouse.fa

the results for HOX and PAX are in RESULTS.txt

the 10000 results are in 10000results.pdf

the bonus alignments for TITIN are in TITIN.txt
